public class Director {
    private String name;
    private String surname;
    private int numDirectedMovie;
    private String DOB;

    public Director() {
        name = "";
        surname = "";
        numDirectedMovie = 0;
        DOB = "";
    }

    public Director(String name, String surname, int numDirectedMovie, String DOB) {
        this.name = name;
        this.surname = surname;
        this.numDirectedMovie = numDirectedMovie;
        this.DOB = DOB;
    }

    public void setName(String name) { this.name = name; }

    public String getName() { return name; }

    public void setSurname(String surname) { this.surname = surname; }

    public String getSurname() { return surname; }

    public void setNumDirectedMovie(String numDirectedMovie) { this.numDirectedMovie = numDirectedMovie }

    public String getNumDirectedMovie() { return numDirectedMovie; }





}
